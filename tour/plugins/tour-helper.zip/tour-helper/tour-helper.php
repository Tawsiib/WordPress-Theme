<?php
    /*
     Plugin Name: Tour-Helper
     Plugin URI:
     Author: Asib Ikbal
     Author URI: https://facebook.com/asib.ikbal
     Description: A companion plugin for tour one page theme
     Version: 1.0
     License: GPLv2 or later
     Text Domain: tour-helper
     Domain Path: /languages/
     */

    function tourh_load_text_domain() {
        load_plugin_textdomain('tour-helper', false, dirname(__FILE__) . '/languages/');
    }
    add_action('plugin_loaded', 'tourh_load_text_domain');

    // Register Custom Post Type

    function tourh_register_my_cpts() {

        /**
         * Post Type: Stories.
         */

        $labels = array(
            "name"                  => __("Stories", "tour"),
            "singular_name"         => __("Story", "tour"),
            "menu_name"             => __("Stories", "tour"),
            "all_items"             => __("All Stories", "tour"),
            "add_new"               => __("Add Story", "tour"),
            "add_new_item"          => __("Add New Story", "tour"),
            "edit_item"             => __("Edit Story", "tour"),
            "new_item"              => __("New Story", "tour"),
            "view_item"             => __("View Story", "tour"),
            "view_items"            => __("View Stories", "tour"),
            "search_items"          => __("Search Stories", "tour"),
            "featured_image"        => __("Story Image", "tour"),
            "set_featured_image"    => __("Set Story Image", "tour"),
            "remove_featured_image" => __("Remove Story Image", "tour"),
            "use_featured_image"    => __("Use Story Image", "tour"),
            "insert_into_item"      => __("Insert into Story", "tour"),
            "uploaded_to_this_item" => __("Uploaded to this story", "tour"),
            "filter_items_list"     => __("Filters Stories List", "tour"),
            "items_list_navigation" => __("Stories List Navigation", "tour"),
            "items_list"            => __("Stories List", "tour"),
        );

        $args = array(
            "label"                 => __("Stories", "tour"),
            "labels"                => $labels,
            "description"           => "",
            "public"                => true,
            "publicly_queryable"    => true,
            "show_ui"               => true,
            "delete_with_user"      => false,
            "show_in_rest"          => false,
            "rest_base"             => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive"           => false,
            "show_in_menu"          => true,
            "show_in_nav_menus"     => true,
            "exclude_from_search"   => false,
            "capability_type"       => "post",
            "map_meta_cap"          => true,
            "hierarchical"          => false,
            "rewrite"               => array("slug" => "Stories", "with_front" => true),
            "query_var"             => true,
            "menu_position"         => 5,
            "menu_icon"             => "dashicons-admin-page",
            "supports"              => array("title", "thumbnail", "excerpt", "author", "page-attributes"),
        );

        register_post_type("story", $args);

        /**
         * Post Type: Sections.
         */

        $labels = array(
            "name"                  => __("Sections", "tour"),
            "singular_name"         => __("Section", "tour"),
            "menu_name"             => __("Sections", "tour"),
            "all_items"             => __("All Sections", "tour"),
            "add_new"               => __("Add Section", "tour"),
            "add_new_item"          => __("Add New Section", "tour"),
            "edit_item"             => __("Edit Section", "tour"),
            "new_item"              => __("New Section", "tour"),
            "view_item"             => __("View Section", "tour"),
            "view_items"            => __("View Sections", "tour"),
            "search_items"          => __("Search Section", "tour"),
            "featured_image"        => __("Section Image", "tour"),
            "set_featured_image"    => __("Set Section Image", "tour"),
            "remove_featured_image" => __("Remove Section Image", "tour"),
            "use_featured_image"    => __("Use Section Image", "tour"),
            "insert_into_item"      => __("Insert into Section", "tour"),
            "uploaded_to_this_item" => __("Upload to this section", "tour"),
            "filter_items_list"     => __("Filter Sections Lists", "tour"),
            "items_list_navigation" => __("Sections List Navigation", "tour"),
            "items_list"            => __("Sections List", "tour"),
        );

        $args = array(
            "label"                 => __("Sections", "tour"),
            "labels"                => $labels,
            "description"           => "",
            "public"                => false,
            "publicly_queryable"    => false,
            "show_ui"               => true,
            "delete_with_user"      => false,
            "show_in_rest"          => false,
            "rest_base"             => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive"           => false,
            "show_in_menu"          => true,
            "show_in_nav_menus"     => true,
            "exclude_from_search"   => true,
            "capability_type"       => "post",
            "map_meta_cap"          => true,
            "hierarchical"          => false,
            "rewrite"               => array("slug" => "section", "with_front" => true),
            "query_var"             => false,
            "menu_position"         => 5,
            "menu_icon"             => "dashicons-pressthis",
            "supports"              => array("title", "thumbnail"),
        );

        register_post_type("section", $args);



    }

    add_action('init', 'tourh_register_my_cpts');
